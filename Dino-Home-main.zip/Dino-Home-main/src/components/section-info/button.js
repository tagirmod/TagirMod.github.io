function openEditor() {
    window.location.href = "https://dinosaurmod.github.io/editor.html"
}

export default openEditor